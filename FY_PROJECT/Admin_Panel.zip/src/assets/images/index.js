
export { default as LoginBgNew } from "./login-new-bg.png";
