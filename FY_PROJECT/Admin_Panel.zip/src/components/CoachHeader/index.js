import { lazy } from "react";

export const CoachHeader = lazy(() => import("./CoachHeader"));
