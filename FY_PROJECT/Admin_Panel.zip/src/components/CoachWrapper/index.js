import { lazy } from "react";
export const CoachWrapper = lazy(() => import("./CoachWrapper"));
