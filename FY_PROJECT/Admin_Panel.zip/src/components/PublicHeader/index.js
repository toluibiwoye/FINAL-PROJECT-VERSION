import { lazy } from "react";

export const PublicHeader = lazy(() => import("./PublicHeader"));
