import { lazy } from "react";

export const TopHeader = lazy(() => import("./TopHeader"));
