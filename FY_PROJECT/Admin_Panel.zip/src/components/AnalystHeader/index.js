import { lazy } from "react";

export const AnalystHeader = lazy(() => import("./AnalystHeader"));
