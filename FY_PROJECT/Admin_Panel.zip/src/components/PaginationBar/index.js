
                  import { lazy } from 'react'
                  
                  export const PaginationBar = lazy(()=> import("./PaginationBar"))
                    