
  import { lazy } from "react";

export const BackButton = lazy(()=> import("./BackButton"))

