import { lazy } from "react";
export const AnalystWrapper = lazy(() => import("./AnalystWrapper"));
