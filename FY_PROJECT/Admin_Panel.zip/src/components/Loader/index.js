
                  import { lazy } from 'react'
                  
                  export const Loader = lazy(()=> import("./Loader"))
                    