
                  import { lazy } from 'react'
                  
                  export const SnackBar = lazy(()=> import("./SnackBar"))
                    