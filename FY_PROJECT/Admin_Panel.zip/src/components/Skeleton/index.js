
    import { lazy } from "react";
  
  export const SkeletonLoader = lazy(()=> import("./Skeleton"))
  
  